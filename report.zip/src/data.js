const data = [
    { id: 1, user: 'Bryan', text: 'Wow this is neat!', likesCount: 2,commentCount:0},
    { id: 2, user: 'You', text: 'youre __right!__', likesCount: 2,commentCount:0},
    { id: 3, user: 'Bryan', text: 'Wow this is neat!', likesCount: 3,commentCount:0},
    { id: 4, user: 'You', text: 'youre __right!__', likesCount: 0,commentCount:0},
    { id: 5, user: 'Bryan', text: 'Wow this is neat!', likesCount: 4,commentCount:0},
    { id: 6, user: 'You', text: 'youre __right!__', likesCount: 1,commentCount:0}
]
module.exports = data;