import React, { Component } from 'react';

class Header extends Component {

    constructor(props){
        super(props);
        this.state = {joke:''};
        this.saveJoke = this.saveJoke.bind(this);
        this.jokeChange = this.jokeChange.bind(this);
    }

    saveJoke(){
        console.log(this.state.joke); 
        this.props.addJoke(this.state.joke);
    }

    jokeChange(e){
        this.setState({ joke: e.target.value });
    }

    render() {
       
        return (
            <div>
            <nav class="navbar navbar-light bg-light fixed-top ">
                <a class="navbar-brand" href="#">
                    <img src="https://getbootstrap.com//assets/brand/bootstrap-solid.svg" width="30" height="30" class="d-inline-block align-top" alt=""/> Jokes Box
                </a>
                <form class="form-inline my-2 my-lg-0">
                    <button class="btn btn-primary my-2 my-sm-0" data-toggle="modal" data-target="#exampleModal">Add Joke</button>
                </form>
            </nav>
            <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Add Joke</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                </div>
                <div class="modal-body">
                <form>
                    <div class="form-group">
                        <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" value={this.state.joke} onChange={ this.jokeChange }></textarea>
                    </div>
                </form>
                </div>
                <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" onClick={this.saveJoke}>Save</button>
                </div>
            </div>
            </div>
            </div>
            </div>
        )
    }
}
export default Header;
